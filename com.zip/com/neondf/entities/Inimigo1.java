package com.neondf.entities;

public class Inimigo1 extends Enemy{
    //precisa de mais uma variável, para a imagem do inimigo

    public Inimigo1(double x, double y){
        super(x, y);
        this.setBaseSpeed(0.8);
        this.setBaseDamage(12);
    }
}