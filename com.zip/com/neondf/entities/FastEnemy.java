package com.neondf.entities;

public class FastEnemy extends Enemy{
    public FastEnemy(double x, double y){
        super(x, y);
        this.changeSpeed(2);
        this.changeHP(0.8);
        this.changeDmg(0.5);
    }
}
